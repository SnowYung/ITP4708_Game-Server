const cardImages = [
    { "src": "/img/Chariot Card.jpg", matched: false },
    { "src": "/img/Death Card.jpg", matched: false },
    { "src": "/img/Devil Card.jpg", matched: false },
    { "src": "/img/Emperor Card.jpg", matched: false },
    { "src": "/img/Empress Card.jpg", matched: false },
    // { "src": "/img/Fool Card.jpg", matched: false },
    // { "src": "/img/Hanged Man Card.jpg", matched: false },
    // { "src": "/img/Hermit Card.jpg", matched: false },
    // { "src": "/img/Hierophant Card.jpg", matched: false },
    // { "src": "/img/High Priestess Card.jpg", matched: false },
    // { "src": "/img/Judgement Card.jpg", matched: false },
    // { "src": "/img/Justice Card.jpg", matched: false },
    // { "src": "/img/Lovers Card.jpg", matched: false },
    // { "src": "/img/Magician Card.jpg", matched: false },
    // { "src": "/img/Moon Card.jpg", matched: false },
    // { "src": "/img/Star Card.jpg", matched: false },
    // { "src": "/img/Strength Card.jpg", matched: false },
    // { "src": "/img/Sun Card.jpg", matched: false },
    // { "src": "/img/Temperance Card.jpg", matched: false },
    // { "src": "/img/Tower Card.jpg", matched: false },
    // { "src": "/img/Wheel of Fortune Card.jpg", matched: false },
    // { "src": "/img/World Card.jpg", matched: false }
];

export default cardImages;